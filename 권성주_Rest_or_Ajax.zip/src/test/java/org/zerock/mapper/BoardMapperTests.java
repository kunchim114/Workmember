package org.zerock.mapper;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.zerock.domain.BoardVO;
import org.zerock.domain.Criteria;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class BoardMapperTests {
	@Setter(onMethod_ = @Autowired)
	private BoardMapper mapper;

	@Test
	public void testPaging() {
		Criteria cri = new Criteria();
		cri.setPageNum(3); // 테스트할 페이지 번호를 지정해주세요.
		cri.setAmount(10); // 한 페이지에 표시할 데이터 개수를 지정해주세요.

		List<BoardVO> list = mapper.getListWithPaging(cri);

		list.forEach(board -> log.info(board.getBno()));
	}

	@Test
	public void testGetList() {
		try {
			mapper.getList().forEach(board -> log.info(board));
		} catch (Exception e) {
			log.error("에러! : " + e.getMessage());
			e.printStackTrace();
		}
	}

	@Test
	public void testInsert() {
		BoardVO board = new BoardVO();
		board.setTitle("제목");
		board.setContent("내용");
		board.setWriter("작성자");
		mapper.insert(board);

		log.info(board);
	}

	@Test
	public void testInsertSelectKey() {
		BoardVO board = new BoardVO();
		board.setTitle("제목");
		board.setContent("내용");
		board.setWriter("작성자");

		mapper.insertSelectKey(board);
		log.info(board);

	}

	@Test
	public void testRead() {
		BoardVO board = mapper.read(5L);

		log.info(board);
	}

	@Test
	public void testDelete() {
		log.info("삭제 수 :" + mapper.delete(3L));
	}

	@Test
	public void testUpdate() {
		BoardVO board = new BoardVO();
		board.setBno(5L);
		board.setTitle("제목");
		board.setContent("내용");
		board.setWriter("uesr00");

		int count = mapper.update(board);
		log.info("수정 횟수 : " + count);
	}

	@Test
	public void testSearch() {
		Criteria cri = new Criteria();
		cri.setKeyword("테스트");
		cri.setType("T");

		List<BoardVO> list = mapper.getListWithPaging(cri);

		list.forEach(board -> log.info(board));
	}

}
